﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.SocialPlatforms;

public class ButtonFunctions : MonoBehaviour {

	private GameObject menuItems;
	private GameObject settingItems;

	void Start()
	{
		menuItems = mainMenu.menu.gameObject;
		settingItems = settingsCanvas.settings.gameObject;
		Social.localUser.Authenticate (ProcessAuthentication);
	}

	void Update()
	{
		settingItems = settingsCanvas.settings.gameObject;
	}

	public void LoadByIndex(int sceneIndex)
	{
		if (sceneIndex == 0) {
			menuItems.SetActive (true);
		} else {
			menuItems.SetActive (false);
		}
		SceneManager.LoadScene (sceneIndex);
	}

	public void ReloadScene() {
			SceneManager.LoadScene (SceneManager.GetActiveScene().buildIndex);
	}

	public void gotoVolCtrl() {
		menuItems.SetActive (false);
		settingItems.SetActive (true);
	}

	public void gotoMenu() {
		menuItems.SetActive (true);
		settingItems.SetActive (false);
	}

	public void showLeaderboard() {
		Social.ShowLeaderboardUI ();
	}

	void ProcessAuthentication (bool success) {
		if (success) {
			Debug.Log ("Authenticated, checking achievements");
		} else {
			Debug.Log ("Failed to authenticate");
		}     
	}
}
