﻿using UnityEngine;
using System.Collections;

public class Ravioli : MonoBehaviour 
{
	public float upForce;					//Upward force of the "flap".
	public AudioClip flapOneSound;
	public AudioClip flapTwoSound;
	public AudioClip flapThreeSound;
	public AudioClip hitSound;

	private bool isntDead = true;			//Has the player collided with a wall?
	private Animator anim;					//Reference to the Animator component.
	private Rigidbody2D rb2d;				//Holds a reference to the Rigidbody2D component of the bird.
	private AudioSource source;
	private float volLowRange = .3f;
	private float volHighRange = .6f;

	void Awake()
	{
		source = GetComponent<AudioSource> ();
	}

	void Start()
	{
		Screen.orientation = ScreenOrientation.Portrait;

		//Get reference to the Animator component attached to this GameObject.
		anim = GetComponent<Animator> ();
		//Get and store a reference to the Rigidbody2D attached to this GameObject.
		rb2d = GetComponent<Rigidbody2D>();
	}

	void Update()
	{
		if (Time.timeScale == 0) {
			if (Input.GetMouseButtonDown (0) || Input.GetTouch(0).phase == TouchPhase.Began) {
				GameControl.instance.startGame ();

				source.PlayOneShot (flapOneSound, .4f);

				//...tell the animator about it and then...
				anim.SetTrigger("Flap");
				//...zero out the birds current y velocity before...
				rb2d.velocity = Vector2.zero;
				//	new Vector2(rb2d.velocity.x, 0);
				//..giving the bird some upward force.
				rb2d.velocity = (new Vector2(0, upForce));
			}
		} else if (isntDead) 
		{
			//Look for input to trigger a "flap".
			if (Input.GetMouseButtonDown(0) || Input.GetTouch(0).phase == TouchPhase.Began)
			{
				float vol = Random.Range (volLowRange, volHighRange);
				float rand = Random.Range (0, 3);
				if (rand < 1) {
					source.PlayOneShot (flapOneSound, vol);
				} else if (rand < 2) {
					source.PlayOneShot (flapTwoSound, vol);
				} else {
					source.PlayOneShot (flapThreeSound, vol);
				}
				//...tell the animator about it and then...
				anim.SetTrigger("Flap");
				//...zero out the birds current y velocity before...
				rb2d.velocity = Vector2.zero;
				//	new Vector2(rb2d.velocity.x, 0);
				//..giving the bird some upward force.
				rb2d.velocity = (new Vector2(0, upForce));
			}
		}
	}

	void OnCollisionEnter2D(Collision2D other)
	{

		if (other.gameObject.CompareTag ("Deadly")) {

			float vol = Random.Range (volLowRange, volHighRange);
			source.PlayOneShot (hitSound, vol);
			// Zero out the bird's velocity
			rb2d.velocity = Vector2.zero;
			// If the bird collides with something set it to dead...
			isntDead = false;
			//...tell the Animator about it...
			anim.SetTrigger ("Die");
			//...and tell the game control about it.
			GameControl.instance.BirdDied ();
		}
			
	}
}
