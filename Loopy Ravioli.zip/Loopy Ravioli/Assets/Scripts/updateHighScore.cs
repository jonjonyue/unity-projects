﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class updateHighScore : MonoBehaviour {

	public Text highScoreText;
	public static updateHighScore update;

	// Use this for initialization
	public void scoreChange(int highscore) {
		highScoreText.text = "Highscore: " + highscore;
	}
}
