﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameControl : MonoBehaviour 
{
	public static GameControl instance;			//A reference to our game control script so we can access it statically.
	public Text scoreText;						//A reference to the UI text component that displays the player's score.
	public GameObject gameOverPanel;				//A reference to the object that displays the text which appears when the player dies.
	public Text startText;
	public Text gameOverText;

	public bool gameOver = false;				//Is the game over?
	public float scrollSpeed = -1.5f;


	void Awake()
	{
		if (instance == null)
			instance = this;
		else if(instance != this)
			Destroy (gameObject);
	}

	void Start()
	{
		if (SceneManager.GetActiveScene().name == "Main")
			Time.timeScale = 0;
		else
			Time.timeScale = 1;
	}

	public void startGame()
	{
		startText.enabled = false;
		Time.timeScale = 1;
		scaleDifficulty ();
	}

	IEnumerator scaleDifficulty() {
		while (enabled) {
			yield return new WaitForSeconds (5f);
			if (Time.timeScale < 2.0f) {
				Time.timeScale += .1f;
			}
		}
	}

	public void BirdDied()
	{
		//Activate the game over text.
		gameOverText.text = "for " + SumScore.Score + " pipes...";
		//Set the game to be over.
		gameOver = true;
		Time.timeScale = 1;

		ReportScore ((long)SumScore.Score, "loopyrav_leaderboard");
		SumScore.SaveHighScore();
		StartCoroutine(gameOverControl());
	}

	void ReportScore(long score, string leaderboardID) {
		Social.ReportScore (score, leaderboardID, success => {
			Debug.Log(success ? "Reported score successfully" : "Failed to report score");
		});
	}

	IEnumerator gameOverControl()
	{
		yield return new WaitForSeconds(1.3f);
		gameOverPanel.SetActive(true);
	}
}
