﻿using UnityEngine;
using System.Collections;

public class Column : MonoBehaviour 
{

	public AudioClip scoreSound;

	private AudioSource source;

	void Awake()
	{
		source = GetComponent<AudioSource> ();
	}

	void OnTriggerEnter2D(Collider2D other)
	{	
		if (other.gameObject.CompareTag ("Player")) {
			//If the bird hits the trigger collider in between the columns then
			// the bird scored.

			source.PlayOneShot (scoreSound, .8f);

			SumScore.Add (1);
		}
	}
}
