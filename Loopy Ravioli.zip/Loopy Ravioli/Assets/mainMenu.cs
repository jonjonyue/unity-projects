﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mainMenu : MonoBehaviour {

	public static mainMenu menu;

	// Use this for initialization
	void Awake() {
		if (menu == null) {
			//...set this one to be it...
			menu = this; 
			DontDestroyOnLoad (gameObject);
		}
		//...otherwise...
		else if(menu != this)
			//...destroy this one because it is a duplicate.
			Destroy (gameObject);
	}
}
