﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class settingsCanvas : MonoBehaviour {

	public static settingsCanvas settings;

	// Use this for initialization
	void Awake () {
		if (settings == null) {
			//...set this one to be it...
			settings = this; 
			DontDestroyOnLoad (gameObject);
			gameObject.SetActive (false);
		}
		//...otherwise...
		else if(settings != this)
			//...destroy this one because it is a duplicate.
			Destroy (gameObject);
	}

}
