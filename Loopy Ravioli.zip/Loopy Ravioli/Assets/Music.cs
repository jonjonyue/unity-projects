﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Music : MonoBehaviour {

	public static Music music;
	public int volume;
	public Slider volumeSlider;
	public Slider sfxSlider;
	public AudioClip test;

	public AudioSource MusicSource;
	public AudioSource SFXSource;

	// Use this for initialization
	void Start () {
		if (music == null) {
			//...set this one to be it...
			music = this; 
			DontDestroyOnLoad (gameObject);

		}
		//...otherwise...
		else if(music != this)
			//...destroy this one because it is a duplicate.
			Destroy (gameObject);


		MusicSource.Play ();
		MusicSource.ignoreListenerVolume = true;
	}
	
	public void changeMusicVolume(){
		MusicSource.volume = volumeSlider.value;
	}

	public void changeSFXVolume()
	{
		AudioListener.volume = sfxSlider.value;
		SFXSource.PlayOneShot (test);
	}
}
